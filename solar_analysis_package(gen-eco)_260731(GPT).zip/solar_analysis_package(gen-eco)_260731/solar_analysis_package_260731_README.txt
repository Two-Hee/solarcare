태양광 발전량 분석 + 태양광 발전 경제성분석 패키지 260731

구성 파일
1. solar_generation_analysis_260731.html
   - 태양광 발전량 분석 최종본
   - 경제성분석 버튼 포함
   - 분석 결과를 localStorage로 저장하여 경제성분석 파일로 전달

2. solar_economic_analysis_260731.html
   - 월간/연간 발전금액, 투자비, 운영비, 회수기간, NPV, ROI, IRR 분석
   - CSV 저장, 인쇄/PDF, PPT 다운로드 기능 포함
   - JSZip과 PptxGenJS를 HTML 내부에 포함하여 오프라인 PPT 생성 지원
   - 선택한 입력조건, 월별 12개월 결과 및 분석기간 전체 연도 결과를 PPT에 수록

3. solar_economic_analysis_260731_PPT_sample.pptx
   - 기본값 25년 조건으로 실제 생성·검증한 PPT 예시

사용 순서
1. 두 HTML 파일을 같은 폴더에 둡니다.
2. solar_generation_analysis_260731.html 을 실행합니다.
3. 발전량 조건을 입력하고 결과를 확인합니다.
4. 좌측 하단의 '경제성분석' 버튼을 누릅니다.
5. 경제성분석 화면에서 단가, 투자비, 운영비를 입력합니다.
6. CSV, 인쇄/PDF, PPT 다운로드를 사용할 수 있습니다.

PPT 기능
- 버튼을 누르면 'PPT 생성 중...' 상태가 표시됩니다.
- 1~50년 전체 연차 결과가 여러 슬라이드로 자동 분할됩니다.
- 상세 발전수익 모드에서는 자가소비·잉여전력·REC·기타수익 구성도 포함됩니다.
- 데이터가 많을 때는 생성에 수 초 이상 걸릴 수 있습니다.

홈페이지 삽입 예시
<iframe src="solar_generation_analysis_260731.html" style="width:100%; height:2100px; border:0;" loading="lazy"></iframe>
<iframe src="solar_economic_analysis_260731.html" style="width:100%; height:2300px; border:0;" loading="lazy"></iframe>
