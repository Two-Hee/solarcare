태양광 발전량 분석 모듈 최종본

파일명: solar_generation_analysis_260731.html
기준일: 2026-07-31

사용 방법
1. HTML 파일을 웹브라우저에서 직접 실행합니다.
2. 홈페이지에 삽입할 경우 iframe 또는 기존 페이지 링크 방식으로 연결합니다.
3. 계산식 상세 내용은 CALCULATION_NOTES 파일을 참조합니다.

권장 삽입 예시
<iframe src="solar_generation_analysis_260731.html" style="width:100%; height:2100px; border:0;" loading="lazy"></iframe>
